"use client";

import { useEffect, useState } from "react";
import { getItems, deleteItem, addItem } from "../lib/indexeddb";
import { Button, Input } from "antd";
import { AnimatePresence } from "framer-motion";
import { motion } from "framer-motion";
import useAppContext from "@/components/Context/UseAppContext";

export default function Page() {
  const [data, setData] = useState("");
  const [items, setItems] = useState<ItemDataList[]>([]);
  // const [selectedId, setSelectedId] = useState(null);
  const { newTask, setNewTask } = useAppContext();
console.log(newTask)
useEffect(() => {
  if (typeof window !== 'undefined') {
    getItems().then((storedItems) => {
      setItems(storedItems);
    });
  }
}, []);

  const handleSave = async () => {
    if (data.trim()) {
      await addItem({ value: data });
      const updatedItems = await getItems();
      setItems(updatedItems);
      setData("");
    }
  };

  const handleDelete = async (id: number) => {
    await deleteItem(id);
    const updatedItems = await getItems();
    setItems(updatedItems);
  };

  return (
    <div className="flex justify-center flex-col  mt-10 my-auto">
      <div className="p-1">
        <div className="text-lg font-bold">کار های امروز</div>
        <div className="text-[18px] text-gray-400 mt-5 font-bold"> امروز</div>
      </div>
      <div className="w-11/12 text-center mt-10  min-h-[300px] mx-auto  rounded-sm ">
        <h2>لیست تسک ها</h2>
        <ul className="w-full">
          {items?.map((item: ItemDataList, index: number) => (
            <li
              key={index}
              className="flex justify-between bg-blue-300 bg-opacity-40 mb-1 rounded-lg p-5"
            >
              <span className="overflow-auto"> {item.value}</span>
              <Button
                className="bg-red-600 text-white"
                onClick={() => handleDelete(item?.id)}
              >
                Delete
              </Button>
            </li>
          ))}
        </ul>

        <AnimatePresence >
          {newTask && (
            <motion.div className="w-full h-[350px]     bg-blue-200 absolute bottom-0 z-20 right-0 left-0 mx-auto rounded-t-xl"  >
                <Input placeholder="عنوان تسک" className="w-3/4" value={data} onChange={(e)=>setData(e.target.value)} />

              <motion.button className="" title="click" onClick={handleSave} >ثبت</motion.button>
              <motion.button className="" title="click" onClick={() => setNewTask(false)} >خروج</motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
