"use client";
import { createContext } from "react";
const AppContext = createContext< any| undefined>(undefined);
export default AppContext;
